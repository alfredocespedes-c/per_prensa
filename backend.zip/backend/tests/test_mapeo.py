"""servicios/mapeo.py: único traductor snake_case (BD) → camelCase (frontend)."""
from tests.conftest import fila_noticia

from app.servicios.mapeo import fila_a_noticia


def test_mapea_todas_las_claves_del_contrato():
    noticia = fila_a_noticia(fila_noticia())

    assert sorted(noticia.keys()) == sorted(
        [
            "id",
            "url",
            "medioId",
            "medioNombre",
            "seccionId",
            "titular",
            "fecha",
            "fechaDeteccion",
            "extracto",
            "imagen",
            "autor",
            "fechaReal",
            "eventId",
            "analisis",
            "excluida",
            "excluidaPor",
        ]
    )
    assert noticia["medioId"] == "medio-uno"
    assert noticia["seccionId"] == "digital"
    # v3: los campos de exclusión van SIEMPRE presentes (los usa la auditoría admin).
    assert noticia["excluida"] is False
    assert noticia["excluidaPor"] == []


def test_extracto_nulo_se_normaliza_a_lista_vacia():
    # El frontend itera extracto sin chequear null: la normalización vive aquí.
    noticia = fila_a_noticia(fila_noticia(extracto=None))
    assert noticia["extracto"] == []


def test_analisis_se_pasa_tal_cual():
    analisis = {"version": 3, "sentimiento": {"polaridad": "neutra"}}
    noticia = fila_a_noticia(fila_noticia(analisis=analisis))
    assert noticia["analisis"] == analisis
