"""Fixtures de tests del backend: cero Postgres y cero IAM.

La sesión falsa de BD interpreta las expresiones reales de SQLAlchemy que emiten
los routers (filter con ==/>=/<=/is_(), order_by con desc()/nullslast(),
offset/limit, y el patrón subquery+join de /api/noticias), así los tests
ejercitan la lógica de consulta de verdad — filtros, orden, ventana y
paginación — sin abrir una conexión.

La autenticación (v3, patrón BFF) se falsifica por dependency_overrides:
`cliente_con(bd, sesion='general'|'admin')` monta una Sesion ya validada;
sin `sesion`, el cliente es anónimo (cookie ausente → el guard real responde 401
en las rutas protegidas, que es parte de lo que se testea).

El TestClient se usa SIN context manager a propósito: el lifespan de app.main
(bootstrap del esquema) requiere la BD y no debe correr en CI.
"""
from datetime import datetime, timezone
from types import SimpleNamespace

import pytest
from fastapi.testclient import TestClient

from app.db.session import get_db
from app.dependencias import Sesion, obtener_sesion, sesion_opcional
from app.main import app


def _columna_y_flags(expresion):
    """Desenrolla Column / desc() / nullslast() a (nombre, descendente, nulls_last)."""
    descendente = False
    nulls_last = False
    actual = expresion
    while hasattr(actual, "element"):
        modificador = getattr(actual, "modifier", None)
        nombre_mod = getattr(modificador, "__name__", "")
        if "desc" in nombre_mod:
            descendente = True
        if "nullslast" in nombre_mod or "nulls_last" in nombre_mod:
            nulls_last = True
        actual = actual.element
    return actual.key, descendente, nulls_last


def _valor_derecho(derecho):
    if hasattr(derecho, "value"):
        return derecho.value
    # Constantes SQL sin .value: is_(False) / is_(True) / is_(None).
    tipo = type(derecho).__name__.lower()
    return {"false_": False, "true_": True, "null": None}.get(tipo)


def _operador(expresion):
    nombre = getattr(expresion.operator, "__name__", "")
    if nombre == "is_":
        return lambda a, b: a is b or a == b
    if nombre in ("is_not", "isnot"):
        return lambda a, b: not (a is b or a == b)
    return expresion.operator  # ==, >=, <= son funciones del módulo operator


class ConsultaFalsa:
    def __init__(self, filas):
        self._filas = list(filas)

    def filter(self, expresion):
        columna = expresion.left.key
        valor = _valor_derecho(expresion.right)
        op = _operador(expresion)
        return ConsultaFalsa(
            fila
            for fila in self._filas
            if getattr(fila, columna, None) is not None and op(getattr(fila, columna), valor)
        )

    def order_by(self, *expresiones):
        filas = list(self._filas)
        # Orden estable multi-clave: se aplica de la última clave a la primera.
        for expresion in reversed(expresiones):
            columna, descendente, nulls_last = _columna_y_flags(expresion)
            con_valor = [f for f in filas if getattr(f, columna) is not None]
            sin_valor = [f for f in filas if getattr(f, columna) is None]
            con_valor.sort(key=lambda f: getattr(f, columna), reverse=descendente)
            filas = con_valor + sin_valor if (nulls_last or not descendente) else sin_valor + con_valor
        return ConsultaFalsa(filas)

    def offset(self, n):
        return ConsultaFalsa(self._filas[n:])

    def limit(self, n):
        return ConsultaFalsa(self._filas[:n])

    def subquery(self):
        # /api/noticias materializa la ventana (LIMIT) como subquery y luego re-consulta
        # con join. En el fake, la "subquery" es simplemente el conjunto de filas ya
        # ordenado y recortado; `.c` existe solo para que el router pueda construir la
        # condición del join (que el join falso ignora: cruza por id).
        self.c = SimpleNamespace(id=None)
        return self

    def join(self, sub, _condicion):
        ids = {fila.id for fila in sub._filas}
        return ConsultaFalsa(fila for fila in self._filas if fila.id in ids)

    def count(self):
        return len(self._filas)

    def all(self):
        return list(self._filas)


class SesionFalsa:
    def __init__(self, noticias=(), secciones=(), metadatos=None, falla_conexion=False):
        self._por_modelo = {"noticias": list(noticias), "secciones": list(secciones)}
        self._metadatos = metadatos
        self._falla_conexion = falla_conexion

    def query(self, entidad):
        # Admite query(Modelo) y query(Modelo.columna) (p. ej. query(Noticia.id)).
        modelo = getattr(entidad, "class_", entidad)
        return ConsultaFalsa(self._por_modelo.get(modelo.__tablename__, []))

    def get(self, modelo, clave):
        if self._falla_conexion:
            raise RuntimeError("host=secreto user=secreto: conexión rechazada")
        return self._metadatos

    def execute(self, _sentencia):
        if self._falla_conexion:
            raise RuntimeError("host=secreto user=secreto: conexión rechazada")
        return SimpleNamespace()


def fila_noticia(**sobrescribe):
    """Fila `noticias` como la deja el archivador del collector (snake_case)."""
    base = dict(
        id="https://mediouno.cl/nota-1",
        url="https://mediouno.cl/nota-1",
        medio_id="medio-uno",
        medio_nombre="Medio Uno",
        seccion_id="digital",
        titular="CONAF anuncia plan de manejo",
        fecha=datetime(2026, 8, 1, 12, 0, tzinfo=timezone.utc),
        fecha_deteccion=datetime(2026, 8, 1, 13, 0, tzinfo=timezone.utc),
        extracto=[{"texto": "CONAF", "resaltado": True}],
        imagen=None,
        autor=None,
        fecha_real=None,
        event_id=None,
        analisis=None,
        excluida=False,
        excluida_por=[],
    )
    base.update(sobrescribe)
    return SimpleNamespace(**base)


def fila_metadatos(**sobrescribe):
    base = dict(
        id=1,
        generado_en=datetime(2026, 8, 1, 13, 5, tzinfo=timezone.utc),
        tamano_ventana=1000,
        actualizado_en=datetime(2026, 8, 1, 13, 5, tzinfo=timezone.utc),
    )
    base.update(sobrescribe)
    return SimpleNamespace(**base)


def _sesion_bff(rol):
    return Sesion(
        sub="u-1",
        usuario="usuaria",
        email="usuaria@conaf.cl",
        rol=rol,
        app_id=1,
        iniciada_en=1_700_000_000,
        expira_en=4_100_000_000,
    )


@pytest.fixture
def cliente_con():
    """Factory: cliente_con(bd, sesion=None|'general'|'admin') → TestClient.

    Sin `sesion` el cliente es anónimo: las rutas públicas responden y las
    protegidas devuelven el 401 del guard real.
    """

    def _factory(bd, sesion=None):
        def _get_db_falso():
            yield bd

        app.dependency_overrides[get_db] = _get_db_falso
        if sesion is not None:
            sesion_valida = _sesion_bff(sesion)
            app.dependency_overrides[obtener_sesion] = lambda: sesion_valida
            app.dependency_overrides[sesion_opcional] = lambda: sesion_valida
        return TestClient(app)

    yield _factory
    app.dependency_overrides.clear()
