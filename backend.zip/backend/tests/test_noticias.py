"""/api/noticias: reemplazo directo de data/noticias.json para el frontend —
mismo shape camelCase y mismo orden que la ventana del collector."""
from datetime import datetime, timezone

from types import SimpleNamespace

from tests.conftest import SesionFalsa, fila_metadatos, fila_noticia


def _seccion(id, nombre, orden):
    return SimpleNamespace(id=id, nombre=nombre, orden=orden)


def test_devuelve_el_contrato_completo_en_camel_case(cliente_con):
    cliente = cliente_con(
        SesionFalsa(
            noticias=[fila_noticia()],
            secciones=[_seccion("digital", "Digital", 4)],
            metadatos=fila_metadatos(),
        )
    )

    respuesta = cliente.get("/api/noticias")

    assert respuesta.status_code == 200
    cuerpo = respuesta.json()
    # Contrato con el frontend: mismas claves que noticias.json (sin las cachés
    # internas resolucionesGoogle/sitemapVisto, que nadie consume).
    assert sorted(cuerpo.keys()) == ["generadoEn", "noticias", "secciones", "tamanoVentana"]
    noticia = cuerpo["noticias"][0]
    assert noticia["medioId"] == "medio-uno"
    assert noticia["medioNombre"] == "Medio Uno"
    assert noticia["fechaDeteccion"].startswith("2026-08-01T13:00")
    assert noticia["extracto"] == [{"texto": "CONAF", "resaltado": True}]
    assert cuerpo["tamanoVentana"] == 1000


def test_la_respuesta_no_es_cacheable(cliente_con):
    # SECOM revisa a las 8:00: una copia cacheada vieja es una página "caída".
    cliente = cliente_con(SesionFalsa(metadatos=fila_metadatos()))
    assert cliente.get("/api/noticias").headers["cache-control"] == "no-store"


def test_ordena_fecha_desc_con_nulos_al_final(cliente_con):
    # Mismo orden que collector/src/dominio/ventana.js: lo más reciente arriba,
    # noticias sin fecha del medio al final.
    filas = [
        fila_noticia(id="a", fecha=datetime(2026, 8, 1, 10, tzinfo=timezone.utc)),
        fila_noticia(id="sin-fecha", fecha=None),
        fila_noticia(id="b", fecha=datetime(2026, 8, 2, 10, tzinfo=timezone.utc)),
    ]
    cliente = cliente_con(SesionFalsa(noticias=filas, metadatos=fila_metadatos()))

    ids = [n["id"] for n in cliente.get("/api/noticias").json()["noticias"]]

    assert ids == ["b", "a", "sin-fecha"]


def test_una_noticia_excluida_no_aparece_para_el_publico(cliente_con):
    # v3, marcado suave: la excluida ocupa cupo de ventana pero no se muestra; el
    # parámetro incluirExcluidas se IGNORA para anónimos (no responde 403 para no
    # confirmar que hay ocultas).
    filas = [
        fila_noticia(id="visible"),
        fila_noticia(id="oculta", excluida=True, excluida_por=["CMPC"]),
    ]
    cliente = cliente_con(SesionFalsa(noticias=filas, metadatos=fila_metadatos()))

    ids = [n["id"] for n in cliente.get("/api/noticias").json()["noticias"]]
    assert ids == ["visible"]

    ids_forzando = [
        n["id"] for n in cliente.get("/api/noticias", params={"incluirExcluidas": "true"}).json()["noticias"]
    ]
    assert ids_forzando == ["visible"]


def test_el_admin_puede_auditar_las_excluidas(cliente_con):
    filas = [
        fila_noticia(id="visible"),
        fila_noticia(id="oculta", excluida=True, excluida_por=["CMPC"]),
    ]
    cliente = cliente_con(SesionFalsa(noticias=filas, metadatos=fila_metadatos()), sesion="admin")

    cuerpo = cliente.get("/api/noticias", params={"incluirExcluidas": "true"}).json()
    porId = {n["id"]: n for n in cuerpo["noticias"]}
    assert set(porId) == {"visible", "oculta"}
    assert porId["oculta"]["excluida"] is True
    assert porId["oculta"]["excluidaPor"] == ["CMPC"]


def test_base_recien_creada_responde_sin_metadatos(cliente_con):
    # Antes de la primera corrida del collector no existe coleccion_metadatos:
    # el endpoint responde igual (página en blanco es un error inaceptable).
    cliente = cliente_con(SesionFalsa(metadatos=None))

    cuerpo = cliente.get("/api/noticias").json()

    assert cuerpo["generadoEn"] is None
    assert cuerpo["noticias"] == []
    assert cuerpo["tamanoVentana"] > 0
