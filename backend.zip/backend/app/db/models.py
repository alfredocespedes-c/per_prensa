"""Modelos SQLAlchemy de SOLO CONSULTA.

Estos modelos NO son la fuente de verdad del esquema — esa es db/schema.sql (ver
db/bootstrap.py). No llamar Base.metadata.create_all() en ningún lado: si este
archivo y el .sql alguna vez difieren, gana el .sql (es lo que realmente se ejecuta
contra Postgres).
"""
from sqlalchemy import ARRAY, BigInteger, Boolean, Column, Computed, DateTime, SmallInteger, Text
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import declarative_base

Base = declarative_base()


class Seccion(Base):
    __tablename__ = "secciones"

    id = Column(Text, primary_key=True)
    nombre = Column(Text, nullable=False)
    orden = Column(SmallInteger, nullable=False)


class Noticia(Base):
    __tablename__ = "noticias"

    id = Column(Text, primary_key=True)
    url = Column(Text, nullable=False)
    medio_id = Column(Text, nullable=False)
    medio_nombre = Column(Text, nullable=False)
    seccion_id = Column(Text, nullable=False)
    titular = Column(Text, nullable=False)
    fecha = Column(DateTime(timezone=True))
    fecha_deteccion = Column(DateTime(timezone=True), nullable=False)
    extracto = Column(JSONB, nullable=False)
    imagen = Column(Text)
    autor = Column(Text)
    fecha_real = Column(DateTime(timezone=True))
    event_id = Column(Text)
    analisis = Column(JSONB)
    sentimiento = Column(Text)
    riesgo = Column(Text)
    prioridad = Column(SmallInteger)
    importancia = Column(SmallInteger)
    ambito = Column(Text)
    categorias = Column(ARRAY(Text))
    regiones = Column(ARRAY(Text))
    # Exclusión por marcado suave: el collector recalcula ambas columnas en cada
    # corrida (ver collector/src/dominio/exclusiones.js). El backend solo las lee.
    excluida = Column(Boolean, nullable=False)
    excluida_por = Column(ARRAY(Text), nullable=False)
    primera_vista_en = Column(DateTime(timezone=True), nullable=False)
    actualizada_en = Column(DateTime(timezone=True), nullable=False)


class Concepto(Base):
    """Conceptos de búsqueda y exclusión, editables por el rol admin.

    Es la primera tabla que este backend ESCRIBE por ORM (el resto es solo lectura).
    La regla que sigue vigente: nada de Base.metadata.create_all() — db/schema.sql es
    la única autoridad del esquema.
    """

    __tablename__ = "conceptos"

    id = Column(BigInteger, primary_key=True)
    texto = Column(Text, nullable=False)
    tipo = Column(Text, nullable=False)  # 'incluir' | 'excluir'
    activo = Column(Boolean, nullable=False, default=True)
    creado_en = Column(DateTime(timezone=True), nullable=False)
    creado_por = Column(Text)
    actualizado_en = Column(DateTime(timezone=True), nullable=False)
    actualizado_por = Column(Text)
    # Computed(..., persisted=True) le dice a SQLAlchemy que la calcula el servidor:
    # sin esto intentaría INSERTARla y Postgres rechazaría el INSERT entero.
    texto_normalizado = Column(Text, Computed("", persisted=True))


class ColeccionMetadatos(Base):
    __tablename__ = "coleccion_metadatos"

    id = Column(SmallInteger, primary_key=True)
    generado_en = Column(DateTime(timezone=True), nullable=False)
    tamano_ventana = Column(BigInteger, nullable=False)
    actualizado_en = Column(DateTime(timezone=True), nullable=False)
