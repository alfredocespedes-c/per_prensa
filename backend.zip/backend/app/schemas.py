"""Modelos de respuesta Pydantic. `EstadoNoticiasOut` reproduce el shape de
noticias.json (ver collector/src/puertos/repositorio-de-noticias.js) para que
frontend/src/datos.js pueda apuntar a este endpoint sin más cambios que la URL.
"""
from datetime import datetime
from typing import Any, Literal, Optional

from pydantic import BaseModel, field_validator

from .servicios.conceptos import normalizar_concepto


class ExtractoFragmento(BaseModel):
    texto: str
    resaltado: bool


class SeccionOut(BaseModel):
    id: str
    nombre: str
    orden: int


class NoticiaOut(BaseModel):
    id: str
    url: str
    medioId: str
    medioNombre: str
    seccionId: str
    titular: str
    fecha: Optional[datetime]
    fechaDeteccion: datetime
    extracto: list[ExtractoFragmento]
    imagen: Optional[str]
    autor: Optional[str]
    fechaReal: Optional[datetime]
    eventId: Optional[str]
    analisis: Optional[dict[str, Any]]
    # Con default para que un backend nuevo contra una fila vieja (antes de que corra
    # la migración) no rompa la validación.
    excluida: bool = False
    excluidaPor: list[str] = []


class EstadoNoticiasOut(BaseModel):
    # Optional porque una base recién creada (antes de la primera corrida del
    # collector) no tiene fila en coleccion_metadatos todavía.
    generadoEn: Optional[datetime]
    tamanoVentana: int
    secciones: list[SeccionOut]
    noticias: list[NoticiaOut]


class HistoricoPageOut(BaseModel):
    pagina: int
    tamanoPagina: int
    total: int
    resultados: list[NoticiaOut]


# --- Conceptos (v3) -----------------------------------------------------------
# La normalización y los límites viven en servicios/conceptos.py para poder testearlos
# sin levantar la app; acá solo se invocan.

TipoConcepto = Literal["incluir", "excluir"]


class ConceptoOut(BaseModel):
    id: int
    texto: str
    tipo: TipoConcepto
    activo: bool
    creadoEn: datetime
    creadoPor: Optional[str]
    actualizadoEn: datetime
    actualizadoPor: Optional[str]


class ConceptosOut(BaseModel):
    conceptos: list[ConceptoOut]
    # Momento en que la próxima corrida del collector aplicará los cambios (cron
    # horario en minuto :00). En UTC: el frontend lo formatea a hora de Chile.
    proximaAplicacion: datetime
    # Si el rol del usuario puede escribir, para que el frontend no re-derive el rol.
    editable: bool


class ConceptoIn(BaseModel):
    texto: str
    tipo: TipoConcepto

    @field_validator("texto")
    @classmethod
    def _normalizar(cls, valor: str) -> str:
        return normalizar_concepto(valor)


class ConceptoPatch(BaseModel):
    texto: Optional[str] = None
    tipo: Optional[TipoConcepto] = None
    activo: Optional[bool] = None

    @field_validator("texto")
    @classmethod
    def _normalizar(cls, valor: Optional[str]) -> Optional[str]:
        return None if valor is None else normalizar_concepto(valor)


class ImpactoConcepto(BaseModel):
    concepto: str
    ocultas: int


class TitularOculto(BaseModel):
    id: str
    url: str
    titular: str
    medioNombre: str
    fecha: Optional[datetime]


class ImpactoOut(BaseModel):
    """Cuántas noticias oculta cada concepto excluido, y cuáles.

    Es la mitigación del riesgo que más importa a SECOM: una exclusión mal escrita
    puede ocultar cobertura legítima en silencio. Acá el admin lo ve literalmente.
    """
    porConcepto: list[ImpactoConcepto]
    titulares: list[TitularOculto]


class SesionOut(BaseModel):
    """Identidad de la sesión actual (GET /api/me).

    `rol` en castellano aunque el IAM lo llame `role`: la traducción ocurre en un
    único punto (el callback). `esAdmin` va precalculado para que el frontend no
    tenga que conocer la lista ROLES_ADMIN.
    """
    usuario: str
    email: str
    rol: str
    esAdmin: bool
    expiraEn: int          # epoch del tope absoluto


class HealthOut(BaseModel):
    status: str
    db: str
    ultimaColecta: Optional[datetime] = None
    minutosDesdeUltimaColecta: Optional[float] = None
    # Nombres (no motivos) de las variables de autenticación que faltan. Permite
    # diagnosticar un despliegue incompleto sin entrar al contenedor; el detalle va
    # solo al log (SEC-07).
    configuracion: Optional[list[str]] = None
