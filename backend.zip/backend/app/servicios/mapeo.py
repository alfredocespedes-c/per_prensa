"""Único lugar que mapea una fila `noticias` (snake_case, ver db/models.py) al shape
camelCase que el frontend espera (ver dominio/noticia.js en el collector)."""


def fila_a_noticia(fila) -> dict:
    return {
        "id": fila.id,
        "url": fila.url,
        "medioId": fila.medio_id,
        "medioNombre": fila.medio_nombre,
        "seccionId": fila.seccion_id,
        "titular": fila.titular,
        "fecha": fila.fecha,
        "fechaDeteccion": fila.fecha_deteccion,
        "extracto": fila.extracto or [],
        "imagen": fila.imagen,
        "autor": fila.autor,
        "fechaReal": fila.fecha_real,
        "eventId": fila.event_id,
        "analisis": fila.analisis,
        # Siempre presentes en el shape, incluso para un usuario general (que solo
        # recibe noticias visibles): la vista de auditoría del admin los necesita y
        # tener el campo opcional obligaría a defenderse en cada consumidor.
        "excluida": bool(fila.excluida),
        "excluidaPor": list(fila.excluida_por or []),
    }
