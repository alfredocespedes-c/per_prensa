"""GET /api/noticias — reemplazo directo de data/noticias.json (ver
frontend/src/datos.js). Mismo orden que collector/src/dominio/ventana.js
(compararNoticias): fecha desc, fecha_deteccion desc, id asc.

Omite deliberadamente resolucionesGoogle/sitemapVisto: son cachés internas del
collector que ningún componente del frontend lee ni valida (ver
frontend/src/contexto/ProveedorDatos.jsx).

Requiere sesión: la dependencia se aplica en el montaje (backend/app/main.py), no acá.
"""
from fastapi import APIRouter, Depends, Query, Response
from sqlalchemy.orm import Session

from ..config import TAMANO_VENTANA
from ..db.models import ColeccionMetadatos, Noticia, Seccion
from ..db.session import get_db
from ..dependencias import Sesion, sesion_opcional
from ..schemas import EstadoNoticiasOut
from ..servicios.mapeo import fila_a_noticia

router = APIRouter()


@router.get("/api/noticias", response_model=EstadoNoticiasOut)
def obtener_noticias(
    response: Response,
    incluirExcluidas: bool = Query(default=False),
    db: Session = Depends(get_db),
    # PÚBLICO: la portada se lee sin iniciar sesión (decisión del mandante). La
    # sesión es opcional y solo sirve para el modo auditoría del admin. El resto
    # de la API sigue exigiéndola (ver main.py).
    sesion: Sesion | None = Depends(sesion_opcional),
) -> dict:
    response.headers["Cache-Control"] = "no-store"

    # La tabla `noticias` es un ARCHIVO acumulativo (el collector hace upsert y nunca
    # borra, ver archivador-postgres.js), no la ventana. Por eso hay que MATERIALIZAR
    # primero la ventana con el LIMIT y filtrar DESPUÉS.
    #
    # Filtrar antes del LIMIT sería un error silencioso y grave: al ocultar N noticias,
    # la consulta rellenaría con las N filas inmediatamente más antiguas —filas que
    # salieron de la ventana hace semanas y cuyo flag `excluida` nunca se recalculó, o
    # sea que siguen en false aunque mencionen el concepto excluido—. Resultado: el
    # concepto excluido SIGUE apareciendo en la portada, y encima vuelven noticias
    # viejas que el collector ya había retirado.
    #
    # Con este orden, ocultar noticias devuelve menos de TAMANO_VENTANA filas: las
    # excluidas ocupan cupo, que es exactamente la semántica que define el collector.
    ventana = (
        db.query(Noticia.id)
        .order_by(
            Noticia.fecha.desc().nullslast(),
            Noticia.fecha_deteccion.desc(),
            Noticia.id.asc(),
        )
        .limit(TAMANO_VENTANA)
        .subquery()
    )
    consulta = db.query(Noticia).join(ventana, Noticia.id == ventana.c.id)

    # Modo auditoría: solo el admin puede ver lo oculto, para comprobar que no se
    # perdió cobertura legítima. Para un usuario general —o anónimo— el parámetro se
    # IGNORA en vez de responder 403: un 403 le confirmaría que hay noticias ocultas.
    if not (incluirExcluidas and sesion is not None and sesion.es_admin):
        consulta = consulta.filter(Noticia.excluida.is_(False))

    noticias = consulta.order_by(
        Noticia.fecha.desc().nullslast(),
        Noticia.fecha_deteccion.desc(),
        Noticia.id.asc(),
    ).all()

    secciones = db.query(Seccion).order_by(Seccion.orden).all()
    metadatos = db.get(ColeccionMetadatos, 1)

    return {
        "generadoEn": metadatos.generado_en if metadatos else None,
        "tamanoVentana": metadatos.tamano_ventana if metadatos else TAMANO_VENTANA,
        "secciones": [{"id": s.id, "nombre": s.nombre, "orden": s.orden} for s in secciones],
        "noticias": [fila_a_noticia(n) for n in noticias],
    }
